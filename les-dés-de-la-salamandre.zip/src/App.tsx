/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AboutPage } from './components/AboutPage';
import { ActivitiesPage } from './components/ActivitiesPage';
import { MembersPage } from './components/MembersPage';
import { GameLibraryPage } from './components/GameLibraryPage';
import { DiceRoller } from './components/DiceRoller';
import { JoinModal } from './components/JoinModal';
import { Footer } from './components/Footer';
import { 
  INITIAL_MEMBERS, 
  INITIAL_EVENTS, 
  INITIAL_CHANNELS, 
  INITIAL_MESSAGES, 
  INITIAL_GAMES, 
  INITIAL_CARPOOLS, 
  INITIAL_LOANS 
} from './data/mockData';
import { Member, EventItem, ChatMessage, CarpoolItem, GameLoanItem, GameItem } from './types';
import { X, CheckCircle, Dices } from 'lucide-react';

export default function App() {
  // Navigation state
  const [currentTab, setCurrentTab] = useState<string>('association');

  // Authenticated Member State
  const [currentMember, setCurrentMember] = useState<Member | null>(() => {
    try {
      const saved = localStorage.getItem('salamandre_active_member');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Events State
  const [events, setEvents] = useState<EventItem[]>(() => {
    try {
      const saved = localStorage.getItem('salamandre_events');
      return saved ? JSON.parse(saved) : INITIAL_EVENTS;
    } catch {
      return INITIAL_EVENTS;
    }
  });

  // Chat Messages State
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('salamandre_messages');
      return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
    } catch {
      return INITIAL_MESSAGES;
    }
  });

  // Loans State
  const [loans, setLoans] = useState<GameLoanItem[]>(() => {
    try {
      const saved = localStorage.getItem('salamandre_loans');
      return saved ? JSON.parse(saved) : INITIAL_LOANS;
    } catch {
      return INITIAL_LOANS;
    }
  });

  // Carpools State
  const [carpools, setCarpools] = useState<CarpoolItem[]>(() => {
    try {
      const saved = localStorage.getItem('salamandre_carpools');
      return saved ? JSON.parse(saved) : INITIAL_CARPOOLS;
    } catch {
      return INITIAL_CARPOOLS;
    }
  });

  // Games State
  const [games] = useState<GameItem[]>(INITIAL_GAMES);

  // Modals state
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [isDiceModalOpen, setIsDiceModalOpen] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3800);
  };

  // Sync to LocalStorage
  useEffect(() => {
    if (currentMember) {
      localStorage.setItem('salamandre_active_member', JSON.stringify(currentMember));
    } else {
      localStorage.removeItem('salamandre_active_member');
    }
  }, [currentMember]);

  useEffect(() => {
    localStorage.setItem('salamandre_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('salamandre_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('salamandre_loans', JSON.stringify(loans));
  }, [loans]);

  useEffect(() => {
    localStorage.setItem('salamandre_carpools', JSON.stringify(carpools));
  }, [carpools]);

  // Auth actions
  const handleLogin = (member: Member) => {
    setCurrentMember(member);
    showToast(`Bienvenue dans l'espace membres, ${member.name} !`);
  };

  const handleLogout = () => {
    setCurrentMember(null);
    showToast('Vous êtes déconnecté(e) de l’espace membres.');
  };

  // Event booking
  const handleBookSeat = (eventId: string, userName: string) => {
    setEvents((prev) =>
      prev.map((evt) => {
        if (evt.id === eventId) {
          if (evt.attendees.includes(userName)) return evt;
          return {
            ...evt,
            reservedSeats: evt.reservedSeats + 1,
            attendees: [userName, ...evt.attendees],
          };
        }
        return evt;
      })
    );
    showToast(`Votre place a bien été enregistrée pour cette session !`);
  };

  const handleCancelBooking = (eventId: string, userName: string) => {
    setEvents((prev) =>
      prev.map((evt) => {
        if (evt.id === eventId) {
          return {
            ...evt,
            reservedSeats: Math.max(0, evt.reservedSeats - 1),
            attendees: evt.attendees.filter((a) => a !== userName),
          };
        }
        return evt;
      })
    );
    showToast(`Votre réservation a été annulée.`);
  };

  // Chat message sending
  const handleSendMessage = (channelId: string, content: string, diceRoll?: any) => {
    if (!currentMember) return;
    const now = new Date();
    const timeStr = `Aujourd’hui à ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const newMsg: ChatMessage = {
      id: Math.random().toString(36).substring(2, 9),
      channelId,
      authorId: currentMember.id,
      authorName: currentMember.name,
      authorRole: currentMember.role,
      authorAvatar: currentMember.avatar,
      content,
      timestamp: timeStr,
      diceRoll,
    };

    setMessages((prev) => [...prev, newMsg]);
  };

  // Peer Game loans
  const handleAddLoan = (item: Omit<GameLoanItem, 'id'>) => {
    const newItem: GameLoanItem = {
      ...item,
      id: `ln-${Date.now()}`,
    };
    setLoans((prev) => [newItem, ...prev]);
    showToast(`Le jeu "${item.gameTitle}" a été ajouté à la bourse aux prêts !`);
  };

  const handleRequestLoan = (loanId: string, userName: string) => {
    setLoans((prev) =>
      prev.map((l) => {
        if (l.id === loanId) {
          return {
            ...l,
            isAvailable: false,
            requestedBy: userName,
          };
        }
        return l;
      })
    );
    showToast(`Demande de prêt enregistrée ! Le propriétaire a été notifié.`);
  };

  // Carpool
  const handleAddCarpool = (item: Omit<CarpoolItem, 'id' | 'passengers'>) => {
    const newCarpool: CarpoolItem = {
      ...item,
      id: `cp-${Date.now()}`,
      passengers: [],
    };
    setCarpools((prev) => [newCarpool, ...prev]);
    showToast(`Votre proposition de trajet a été publiée !`);
  };

  const handleJoinCarpool = (carpoolId: string, userName: string) => {
    setCarpools((prev) =>
      prev.map((c) => {
        if (c.id === carpoolId && !c.passengers.includes(userName)) {
          return {
            ...c,
            passengers: [...c.passengers, userName],
          };
        }
        return c;
      })
    );
    showToast(`Vous avez réservé une place dans cette voiture !`);
  };

  // Join submission success
  const handleJoinSuccess = (name: string, plan: string) => {
    setIsJoinModalOpen(false);
    showToast(`Merci ${name} ! Votre demande d'adhésion a été transmise au bureau.`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#050b14] text-slate-100 selection:bg-sky-500/30 selection:text-orange-200">
      {/* Top Bar Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentMember={currentMember}
        onOpenJoinModal={() => setIsJoinModalOpen(true)}
        onToggleDiceModal={() => setIsDiceModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        {currentTab === 'association' && (
          <AboutPage
            members={INITIAL_MEMBERS}
            onNavigateToActivities={() => setCurrentTab('activites')}
            onNavigateToGames={() => setCurrentTab('ludotheque')}
            onOpenJoinModal={() => setIsJoinModalOpen(true)}
          />
        )}

        {currentTab === 'activites' && (
          <ActivitiesPage
            events={events}
            currentMember={currentMember}
            onBookSeat={handleBookSeat}
            onCancelBooking={handleCancelBooking}
            onOpenJoinModal={() => setIsJoinModalOpen(true)}
          />
        )}

        {currentTab === 'ludotheque' && (
          <GameLibraryPage
            games={games}
            onOpenJoinModal={() => setIsJoinModalOpen(true)}
          />
        )}

        {currentTab === 'membres' && (
          <MembersPage
            currentMember={currentMember}
            allMembers={INITIAL_MEMBERS}
            onLogin={handleLogin}
            onLogout={handleLogout}
            channels={INITIAL_CHANNELS}
            messages={messages}
            onSendMessage={handleSendMessage}
            events={events}
            carpools={carpools}
            loans={loans}
            onAddLoan={handleAddLoan}
            onAddCarpool={handleAddCarpool}
            onJoinCarpool={handleJoinCarpool}
            onRequestLoan={handleRequestLoan}
            onBookSeat={handleBookSeat}
            onOpenJoinModal={() => setIsJoinModalOpen(true)}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        onNavigate={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenJoinModal={() => setIsJoinModalOpen(true)}
      />

      {/* Floating Action Button for Dice Roller */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          type="button"
          onClick={() => setIsDiceModalOpen(!isDiceModalOpen)}
          className="flex items-center gap-2 px-3.5 py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-full shadow-lg shadow-orange-950/60 transition-transform hover:scale-105 active:scale-95 cursor-pointer border border-orange-400/40"
          title="Lancer les dés"
        >
          <Dices className="w-5 h-5 fill-slate-950 stroke-slate-950" />
          <span className="text-xs hidden sm:inline">Lancer les dés</span>
        </button>
      </div>

      {/* Floating Dice Roller Modal */}
      {isDiceModalOpen && (
        <div className="fixed bottom-20 right-4 sm:right-6 z-50 w-[92vw] sm:w-[420px] shadow-2xl transition-all">
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsDiceModalOpen(false)}
              className="absolute -top-3 -right-3 z-10 w-7 h-7 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-full flex items-center justify-center border border-slate-600 shadow-md cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <DiceRoller />
          </div>
        </div>
      )}

      {/* Join & Membership Modal */}
      <JoinModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
        onSuccess={handleJoinSuccess}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 bg-slate-900 border border-sky-400/50 rounded-xl shadow-xl flex items-center gap-2 text-xs text-sky-200 animate-fade-in">
          <CheckCircle className="w-4 h-4 text-orange-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
