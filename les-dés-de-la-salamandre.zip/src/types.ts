export type UserRole = 'adhérent' | 'maître-du-jeu' | 'bureau' | 'animateur';

export interface Member {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: UserRole;
  roleTitle: string;
  bio: string;
  memberSince: string;
  favoriteGames: string[];
}

export type EventCategory = 'plateau' | 'jdr' | 'tournoi' | 'initiation' | 'membre-exclusif' | 'special';

export interface EventItem {
  id: string;
  title: string;
  category: EventCategory;
  categoryLabel: string;
  date: string;
  formattedDate: string;
  time: string;
  location: string;
  maxSeats: number;
  reservedSeats: number;
  attendees: string[];
  host: string;
  hostRole: string;
  description: string;
  complexity: 'Tous publics' | 'Initié' | 'Expert';
  isMemberOnly: boolean;
  bringItems?: string;
}

export interface DiceRollResult {
  dice?: string;
  type?: string;
  count?: number;
  modifier?: number;
  rolls?: number[];
  total?: number;
  result?: number;
  detail?: string;
  isCriticalSuccess?: boolean;
  isCriticalFail?: boolean;
  timestamp?: string;
}

export interface ChatMessage {
  id: string;
  channelId: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorAvatar: string;
  content: string;
  timestamp: string;
  diceRoll?: DiceRollResult;
}

export interface ChatChannel {
  id: string;
  name: string;
  topic: string;
  description?: string;
  isPrivate: boolean;
  category: 'communauté' | 'tables-de-jeu' | 'pratique';
}

export interface GameItem {
  id: string;
  title: string;
  category: string;
  playersMin: number;
  playersMax: number;
  durationMin: number;
  complexity: 'Accessible' | 'Intermédiaire' | 'Stratégique';
  description: string;
  available: boolean;
  location: string;
  rating: number;
  tags: string[];
}

export interface CarpoolItem {
  id: string;
  eventTitle?: string;
  driverName: string;
  departureCity?: string;
  departureTime?: string;
  seatsAvailable?: number;
  origin?: string;
  destination?: string;
  dateTime?: string;
  availableSeats?: number;
  notes?: string;
  passengers: string[];
}

export interface GameLoanItem {
  id: string;
  gameTitle: string;
  ownerName: string;
  condition?: string;
  loanDuration?: string;
  maxDuration?: string;
  notes?: string;
  isAvailable: boolean;
  requestedBy?: string;
}
