import React, { useState } from 'react';
import { Sparkles, RotateCcw, Volume2, VolumeX, Flame } from 'lucide-react';
import { DiceRollResult } from '../types';

interface DiceRollerProps {
  onRollComplete?: (result: DiceRollResult) => void;
  compact?: boolean;
}

export const DiceRoller: React.FC<DiceRollerProps> = ({ onRollComplete, compact = false }) => {
  const [selectedDice, setSelectedDice] = useState<number>(20);
  const [diceCount, setDiceCount] = useState<number>(1);
  const [modifier, setModifier] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [currentResult, setCurrentResult] = useState<DiceRollResult | null>(null);
  const [history, setHistory] = useState<DiceRollResult[]>([]);

  const diceTypes = [
    { sides: 4, label: 'd4', color: 'border-slate-700 hover:border-sky-400' },
    { sides: 6, label: 'd6', color: 'border-yellow-500/50 bg-yellow-950/20 text-yellow-300' }, // Match logo d6
    { sides: 8, label: 'd8', color: 'border-slate-700 hover:border-sky-400' },
    { sides: 10, label: 'd10', color: 'border-slate-700 hover:border-sky-400' },
    { sides: 12, label: 'd12', color: 'border-slate-700 hover:border-sky-400' },
    { sides: 20, label: 'd20', color: 'border-sky-500/60 bg-sky-950/30 text-sky-300' }, // Match logo d20
    { sides: 100, label: 'd100', color: 'border-slate-700 hover:border-sky-400' },
  ];

  // Synthesize pleasant sound click without external audio files
  const playRollSound = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(140, audioCtx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.12);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + 0.13);
    } catch {
      // AudioContext may be blocked or unavailable
    }
  };

  const handleRoll = () => {
    if (isRolling) return;
    setIsRolling(true);
    playRollSound();

    let rollFrames = 0;
    const interval = setInterval(() => {
      rollFrames++;
      if (rollFrames > 6) {
        clearInterval(interval);

        const individualRolls: number[] = [];
        for (let i = 0; i < diceCount; i++) {
          individualRolls.push(Math.floor(Math.random() * selectedDice) + 1);
        }

        const sum = individualRolls.reduce((a, b) => a + b, 0);
        const total = sum + modifier;
        const isCriticalSuccess = selectedDice === 20 && individualRolls.includes(20);
        const isCriticalFail = selectedDice === 20 && individualRolls.includes(1);

        const now = new Date();
        const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

        const result: DiceRollResult = {
          dice: `d${selectedDice}`,
          count: diceCount,
          modifier,
          rolls: individualRolls,
          total,
          isCriticalSuccess,
          isCriticalFail,
          timestamp: timeStr,
        };

        setCurrentResult(result);
        setHistory((prev) => [result, ...prev.slice(0, 9)]);
        setIsRolling(false);

        if (onRollComplete) {
          onRollComplete(result);
        }
      }
    }, 50);
  };

  return (
    <div className="bg-slate-900/95 border border-sky-950/80 rounded-2xl p-5 shadow-2xl backdrop-blur-md text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-orange-500 to-amber-500 text-slate-950 flex items-center justify-center font-bold text-xs">
            <Flame className="w-3.5 h-3.5 fill-slate-950" />
          </div>
          <h3 className="font-serif text-sm font-bold text-slate-100">
            Lancer de Dés Polyédriques
          </h3>
        </div>

        <button
          type="button"
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="text-slate-400 hover:text-sky-300 p-1 rounded cursor-pointer"
          title={soundEnabled ? 'Désactiver le son' : 'Activer le son'}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>

      {/* Dice Selection */}
      <div className="py-4 space-y-3">
        <div className="grid grid-cols-7 gap-1.5">
          {diceTypes.map((d) => (
            <button
              key={d.sides}
              type="button"
              onClick={() => setSelectedDice(d.sides)}
              className={`py-2 px-1 text-center rounded-lg border text-xs font-mono font-bold transition-all cursor-pointer ${
                selectedDice === d.sides
                  ? d.sides === 6
                    ? 'bg-yellow-400 text-slate-950 border-yellow-300 shadow-sm'
                    : 'bg-sky-500 text-slate-950 border-sky-400 shadow-sm'
                  : `bg-slate-950 text-slate-300 ${d.color}`
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>

        {/* Quantité & Modificateur */}
        <div className="flex items-center justify-between gap-3 text-xs bg-slate-950 p-2.5 rounded-xl border border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Nb de dés :</span>
            <div className="flex items-center gap-1 font-mono">
              <button
                type="button"
                onClick={() => setDiceCount(Math.max(1, diceCount - 1))}
                className="w-5 h-5 bg-slate-800 hover:bg-slate-700 rounded text-slate-200 flex items-center justify-center cursor-pointer"
              >
                -
              </button>
              <span className="w-5 text-center font-bold text-sky-400">{diceCount}</span>
              <button
                type="button"
                onClick={() => setDiceCount(Math.min(10, diceCount + 1))}
                className="w-5 h-5 bg-slate-800 hover:bg-slate-700 rounded text-slate-200 flex items-center justify-center cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Bonus/Malus :</span>
            <div className="flex items-center gap-1 font-mono">
              <button
                type="button"
                onClick={() => setModifier(modifier - 1)}
                className="w-5 h-5 bg-slate-800 hover:bg-slate-700 rounded text-slate-200 flex items-center justify-center cursor-pointer"
              >
                -
              </button>
              <span className="w-7 text-center font-bold text-orange-400">
                {modifier >= 0 ? `+${modifier}` : modifier}
              </span>
              <button
                type="button"
                onClick={() => setModifier(modifier + 1)}
                className="w-5 h-5 bg-slate-800 hover:bg-slate-700 rounded text-slate-200 flex items-center justify-center cursor-pointer"
              >
                +
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Roll Action */}
      <div className="space-y-3">
        <button
          type="button"
          onClick={handleRoll}
          disabled={isRolling}
          className="w-full py-3 bg-gradient-to-r from-orange-500 via-amber-500 to-sky-500 hover:from-orange-400 hover:to-sky-400 text-slate-950 font-bold rounded-xl text-xs uppercase tracking-wider transition-all shadow-md active:scale-98 cursor-pointer flex items-center justify-center gap-2"
        >
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>
            {isRolling
              ? 'Lancement en cours...'
              : `Lancer ${diceCount}d${selectedDice} ${modifier !== 0 ? (modifier > 0 ? `+${modifier}` : modifier) : ''}`}
          </span>
        </button>

        {/* Current Result Showcase */}
        {currentResult && (
          <div
            className={`p-4 rounded-xl border text-center transition-all ${
              currentResult.isCriticalSuccess
                ? 'bg-amber-950/40 border-yellow-400 text-yellow-300'
                : currentResult.isCriticalFail
                ? 'bg-red-950/40 border-red-500 text-red-300'
                : 'bg-slate-950 border-sky-900/60 text-slate-100'
            }`}
          >
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-1">
              <span>
                Formule : {currentResult.count ?? 1}
                {currentResult.dice ?? 'd20'}
                {(currentResult.modifier ?? 0) !== 0
                  ? (currentResult.modifier ?? 0) > 0
                    ? `+${currentResult.modifier}`
                    : currentResult.modifier
                  : ''}
              </span>
              <span>Détail : [{currentResult.rolls?.join(', ') ?? currentResult.detail ?? ''}]</span>
            </div>

            <div className="font-serif text-3xl font-extrabold tracking-tight py-1 font-mono">
              {currentResult.total}
            </div>

            {currentResult.isCriticalSuccess && (
              <span className="inline-block text-[11px] font-mono text-yellow-400 font-bold uppercase tracking-wider animate-bounce mt-1">
                ★ Succès Critique Naturel (20) ! ★
              </span>
            )}

            {currentResult.isCriticalFail && (
              <span className="inline-block text-[11px] font-mono text-red-400 font-bold uppercase tracking-wider mt-1">
                ⚠ Échec Critique Naturel (1) ⚠
              </span>
            )}
          </div>
        )}

        {/* History Peek */}
        {!compact && history.length > 1 && (
          <div className="pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
              <span>Derniers lancers :</span>
              <button
                type="button"
                onClick={() => setHistory([])}
                className="text-slate-500 hover:text-slate-300 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" /> Effacer
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-16 overflow-y-auto">
              {history.slice(1, 6).map((h, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300"
                >
                  {h.count}
                  {h.dice}: <strong className="text-sky-400">{h.total}</strong>
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
