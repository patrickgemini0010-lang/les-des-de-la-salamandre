import React, { useState } from 'react';
import { 
  Lock, 
  MessageSquare, 
  Calendar, 
  Car, 
  BookOpen, 
  Send, 
  User, 
  LogOut, 
  Plus, 
  Check, 
  Sparkles,
  MapPin,
  Clock,
  ShieldCheck,
  Dices
} from 'lucide-react';
import { 
  Member, 
  ChatChannel, 
  ChatMessage, 
  EventItem, 
  CarpoolItem, 
  GameLoanItem,
  DiceRollResult 
} from '../types';

interface MembersPageProps {
  currentMember: Member | null;
  allMembers: Member[];
  onLogin: (member: Member) => void;
  onLogout: () => void;
  channels: ChatChannel[];
  messages: ChatMessage[];
  onSendMessage: (channelId: string, content: string, diceRoll?: DiceRollResult) => void;
  events: EventItem[];
  carpools: CarpoolItem[];
  loans: GameLoanItem[];
  onAddLoan: (item: Omit<GameLoanItem, 'id'>) => void;
  onAddCarpool: (item: Omit<CarpoolItem, 'id' | 'passengers'>) => void;
  onJoinCarpool: (carpoolId: string, userName: string) => void;
  onRequestLoan: (loanId: string, userName: string) => void;
  onBookSeat: (eventId: string, userName: string) => void;
  onOpenJoinModal: () => void;
}

export const MembersPage: React.FC<MembersPageProps> = ({
  currentMember,
  allMembers,
  onLogin,
  onLogout,
  channels,
  messages,
  onSendMessage,
  events,
  carpools,
  loans,
  onAddLoan,
  onAddCarpool,
  onJoinCarpool,
  onRequestLoan,
  onBookSeat,
  onOpenJoinModal,
}) => {
  // Tabs inside members area
  const [activeTab, setActiveTab] = useState<'chat' | 'events' | 'loans' | 'carpool'>('chat');
  const [activeChannelId, setActiveChannelId] = useState<string>('c-1');
  const [messageInput, setMessageInput] = useState<string>('');

  // New Loan Form Modal
  const [isAddingLoan, setIsAddingLoan] = useState<boolean>(false);
  const [newLoanTitle, setNewLoanTitle] = useState<string>('');
  const [newLoanDuration, setNewLoanDuration] = useState<string>('2 semaines');
  const [newLoanNotes, setNewLoanNotes] = useState<string>('');

  // New Carpool Form Modal
  const [isAddingCarpool, setIsAddingCarpool] = useState<boolean>(false);
  const [newCarpoolOrigin, setNewCarpoolOrigin] = useState<string>('');
  const [newCarpoolDestination, setNewCarpoolDestination] = useState<string>('Local de l’Association (Maison des Assos)');
  const [newCarpoolDate, setNewCarpoolDate] = useState<string>('Ce vendredi à 19h30');
  const [newCarpoolSeats, setNewCarpoolSeats] = useState<number>(3);

  // Direct roll inside chat
  const handleQuickDiceRoll = (sides: number) => {
    if (!currentMember) return;
    const roll = Math.floor(Math.random() * sides) + 1;
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const diceResult: DiceRollResult = {
      dice: `d${sides}`,
      count: 1,
      modifier: 0,
      rolls: [roll],
      total: roll,
      isCriticalSuccess: sides === 20 && roll === 20,
      isCriticalFail: sides === 20 && roll === 1,
      timestamp: timeStr,
    };

    onSendMessage(
      activeChannelId,
      `*A lancé un d${sides}* 🎲`,
      diceResult
    );
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;
    onSendMessage(activeChannelId, messageInput.trim());
    setMessageInput('');
  };

  const handleCreateLoanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLoanTitle.trim() || !currentMember) return;

    onAddLoan({
      gameTitle: newLoanTitle.trim(),
      ownerName: currentMember.name,
      maxDuration: newLoanDuration,
      notes: newLoanNotes.trim() || 'Boîte complète en excellent état.',
      isAvailable: true,
    });

    setNewLoanTitle('');
    setNewLoanNotes('');
    setIsAddingLoan(false);
  };

  const handleCreateCarpoolSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCarpoolOrigin.trim() || !currentMember) return;

    onAddCarpool({
      driverName: currentMember.name,
      origin: newCarpoolOrigin.trim(),
      destination: newCarpoolDestination,
      dateTime: newCarpoolDate,
      availableSeats: newCarpoolSeats,
    });

    setNewCarpoolOrigin('');
    setIsAddingCarpool(false);
  };

  // If NOT logged in, show clean authentic member login portal
  if (!currentMember) {
    return (
      <div className="py-12 max-w-xl mx-auto space-y-8">
        <div className="text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-sky-950/80 border border-sky-800/80 text-sky-400 flex items-center justify-center mx-auto shadow-xl">
            <Lock className="w-7 h-7 text-orange-400" />
          </div>
          <h1 className="font-serif text-3xl font-bold text-slate-100">
            Espace Membres Sécurisé
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
            Cet espace privé est réservé aux adhérents de l’association (15 €/an). 
            Il donne accès aux salons thématiques, au calendrier des sessions privées, 
            au prêt de jeux entre joueurs et au covoiturage.
          </p>
        </div>

        {/* Quick demo sign-in profiles */}
        <div className="rounded-2xl border border-sky-950/80 bg-slate-900/80 p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-sky-400 uppercase tracking-wider">
              Connexion Démonstration Adhérent
            </span>
            <span className="text-[11px] text-slate-500 font-mono">1-Clic</span>
          </div>
          <p className="text-xs text-slate-400">
            Sélectionnez un membre de l'association pour tester les salons et les fonctionnalités :
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {allMembers.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => onLogin(m)}
                className="p-3 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-sky-500/60 transition-all text-left flex items-center gap-3 cursor-pointer group"
              >
                <img
                  src={m.avatar}
                  alt={m.name}
                  className="w-10 h-10 rounded-full object-cover border border-orange-500/40"
                  referrerPolicy="no-referrer"
                />
                <div className="min-w-0">
                  <div className="font-semibold text-xs text-slate-200 group-hover:text-sky-300 truncate">
                    {m.name}
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono truncate">{m.roleTitle}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Pas encore adhérent ? */}
        <div className="rounded-xl border border-orange-500/30 bg-orange-950/20 p-5 text-center space-y-3">
          <h3 className="font-serif text-base font-bold text-slate-100">
            Vous n'êtes pas encore adhérent(e) ?
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            L'adhésion annuelle ne coûte que 15 € et vous offre un accès illimité à toutes les activités, 
            la ludothèque de 350+ jeux et la communauté.
          </p>
          <button
            type="button"
            onClick={onOpenJoinModal}
            className="px-5 py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-lg text-xs transition-all shadow-md cursor-pointer"
          >
            Demander une adhésion en ligne
          </button>
        </div>
      </div>
    );
  }

  // LOGGED IN STATE
  const currentChannel = channels.find((c) => c.id === activeChannelId) || channels[0];
  const channelMessages = messages.filter((m) => m.channelId === activeChannelId);

  return (
    <div className="space-y-6 py-6 pb-20">
      {/* Top Welcome Bar for the logged in member */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-slate-900/90 border border-sky-950/80 shadow-md">
        <div className="flex items-center gap-3.5">
          <div className="relative">
            <img
              src={currentMember.avatar}
              alt={currentMember.name}
              className="w-12 h-12 rounded-full object-cover border-2 border-orange-500"
              referrerPolicy="no-referrer"
            />
            <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-950 rounded-full" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-serif text-lg font-bold text-slate-100">{currentMember.name}</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800/60">
                {currentMember.roleTitle}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Adhésion 2026 active</span>
              <span>·</span>
              <span>Membre depuis {currentMember.memberSince}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            type="button"
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-red-400 hover:bg-slate-950 rounded-lg border border-slate-800 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>

      {/* Tabs Selection inside Member Area */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('chat')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'chat'
              ? 'bg-sky-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Salons Thématiques & Chat</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('events')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'events'
              ? 'bg-sky-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Événements Spécial Membres</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('loans')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'loans'
              ? 'bg-sky-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Bourse aux Prêts entre Adhérents</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('carpool')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'carpool'
              ? 'bg-sky-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Car className="w-4 h-4" />
          <span>Covoiturage Ludique</span>
        </button>
      </div>

      {/* TAB 1: PRIVATE CHAT ROOMS */}
      {activeTab === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-[650px] border border-sky-950/80 rounded-2xl overflow-hidden bg-slate-950 shadow-2xl">
          {/* Channels list sidebar */}
          <div className="lg:col-span-1 border-b lg:border-b-0 lg:border-r border-slate-800 bg-slate-900/60 p-3 space-y-2 overflow-y-auto">
            <div className="px-2 py-1 text-[11px] font-mono text-sky-400 uppercase tracking-wider font-semibold">
              Salons Thématiques
            </div>

            <div className="space-y-1">
              {channels.map((chan) => {
                const isActive = chan.id === activeChannelId;
                return (
                  <button
                    key={chan.id}
                    type="button"
                    onClick={() => setActiveChannelId(chan.id)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-between ${
                      isActive
                        ? 'bg-sky-950/70 text-sky-300 border border-sky-800/80 font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <div className="truncate">
                      <span className="font-mono text-orange-400 mr-1.5">#</span>
                      <span>{chan.name}</span>
                    </div>
                    {chan.isPrivate && <Lock className="w-3 h-3 text-orange-400 shrink-0 ml-1" />}
                  </button>
                );
              })}
            </div>

            {/* Quick in-chat dice roll buttons */}
            <div className="pt-4 border-t border-slate-800 px-2 space-y-2">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                Lancer de Dé Rapide :
              </span>
              <div className="grid grid-cols-4 gap-1.5 text-xs font-mono">
                <button
                  type="button"
                  onClick={() => handleQuickDiceRoll(6)}
                  className="py-1 bg-yellow-950/40 hover:bg-yellow-900/60 text-yellow-300 rounded border border-yellow-500/40 text-center cursor-pointer"
                >
                  d6
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDiceRoll(10)}
                  className="py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 rounded border border-slate-700 text-center cursor-pointer"
                >
                  d10
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDiceRoll(20)}
                  className="py-1 bg-sky-950/60 hover:bg-sky-900/60 text-sky-300 rounded border border-sky-500/40 text-center cursor-pointer font-bold"
                >
                  d20
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDiceRoll(100)}
                  className="py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 rounded border border-slate-700 text-center cursor-pointer"
                >
                  d100
                </button>
              </div>
            </div>
          </div>

          {/* Chat messages viewport */}
          <div className="lg:col-span-3 flex flex-col justify-between h-full bg-[#050b14]">
            {/* Channel header */}
            <div className="px-5 py-3.5 border-b border-slate-800 bg-slate-900/50 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-1.5 font-bold text-sm text-slate-100">
                  <span className="text-orange-400 font-mono">#</span>
                  <span>{currentChannel.name}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">{currentChannel.description}</p>
              </div>
            </div>

            {/* Messages scroll area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {channelMessages.map((msg) => {
                const isMe = msg.authorId === currentMember.id;

                return (
                  <div key={msg.id} className="flex items-start gap-3 text-xs">
                    <img
                      src={msg.authorAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                      alt={msg.authorName}
                      className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0 mt-0.5"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 space-y-1">
                      <div className="flex items-baseline gap-2">
                        <span className={`font-semibold ${isMe ? 'text-orange-400' : 'text-slate-200'}`}>
                          {msg.authorName}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">{msg.timestamp}</span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80 text-slate-300 leading-relaxed max-w-2xl">
                        {msg.content}

                        {/* Embedded Dice Roll */}
                        {msg.diceRoll && (
                          <div className="mt-2 p-2.5 rounded-lg bg-slate-950 border border-sky-900/80 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Dices className="w-4 h-4 text-sky-400" />
                              <span className="font-mono text-slate-400">
                                Lancer {msg.diceRoll.type || `${msg.diceRoll.count || 1}${msg.diceRoll.dice || 'd20'}`} :
                              </span>
                            </div>
                            <div className="flex items-center gap-2 font-mono">
                              <span className="text-slate-400">
                                [{msg.diceRoll.rolls?.join(', ') || msg.diceRoll.detail || ''}]
                              </span>
                              <span
                                className={`text-base font-extrabold px-2 py-0.5 rounded ${
                                  msg.diceRoll.isCriticalSuccess
                                    ? 'bg-yellow-400 text-slate-950'
                                    : msg.diceRoll.isCriticalFail
                                    ? 'bg-red-500 text-white'
                                    : 'bg-sky-500 text-slate-950'
                                }`}
                              >
                                {msg.diceRoll.total ?? msg.diceRoll.result ?? 0}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Input Form */}
            <form onSubmit={handleSendChat} className="p-3 border-t border-slate-800 bg-slate-900/80 flex gap-2">
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder={`Envoyer un message dans #${currentChannel.name}...`}
                className="flex-1 px-4 py-2 text-xs bg-slate-950 border border-slate-800 focus:border-sky-400 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>Envoyer</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 2: EXCLUSIVE MEMBER EVENTS */}
      {activeTab === 'events' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="font-serif text-lg font-bold text-slate-100">
                Sessions & Tournois Exclusifs aux Adhérents
              </h3>
              <p className="text-xs text-slate-400">
                Ces sessions spéciales sont réservées aux membres à jour de cotisation (15 €/an).
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {events
              .filter((e) => e.isMemberOnly)
              .map((evt) => {
                const isBooked = evt.attendees.includes(currentMember.name);
                return (
                  <div key={evt.id} className="p-5 rounded-xl bg-slate-900 border border-sky-900/60 space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono text-orange-400">{evt.categoryLabel}</span>
                      <span className="text-slate-400">{evt.formattedDate}</span>
                    </div>

                    <h4 className="font-serif text-lg font-bold text-slate-100">{evt.title}</h4>
                    <p className="text-xs text-slate-400">{evt.description}</p>

                    <div className="text-xs text-slate-300 pt-2 border-t border-slate-800 space-y-1">
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-sky-400" />
                        <span>{evt.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-yellow-400" />
                        <span>{evt.location}</span>
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-between">
                      <span className="text-xs text-slate-400">
                        Inscrits : <strong>{evt.reservedSeats}</strong> / {evt.maxSeats}
                      </span>

                      {isBooked ? (
                        <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1 rounded">
                          ✓ Place réservée
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onBookSeat(evt.id, currentMember.name)}
                          className="px-3 py-1.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-lg text-xs cursor-pointer"
                        >
                          Réserver ma place
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* TAB 3: GAME LOANS BETWEEN MEMBERS */}
      {activeTab === 'loans' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="font-serif text-lg font-bold text-slate-100">
                Bourse aux Prêts de Jeux
              </h3>
              <p className="text-xs text-slate-400">
                Prêtez ou empruntez des boîtes entre adhérents de confiance en toute sérénité.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsAddingLoan(!isAddingLoan)}
              className="px-3.5 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Proposer un jeu au prêt</span>
            </button>
          </div>

          {/* New Loan Form Modal Drawer */}
          {isAddingLoan && (
            <form onSubmit={handleCreateLoanSubmit} className="p-4 rounded-xl bg-slate-900 border border-sky-900 space-y-3 text-xs">
              <h4 className="font-bold text-slate-100">Proposer une boîte de votre collection :</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Nom du jeu *</label>
                  <input
                    type="text"
                    required
                    value={newLoanTitle}
                    onChange={(e) => setNewLoanTitle(e.target.value)}
                    placeholder="Ex: Scythe, Terraforming Mars..."
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Durée maximale de prêt</label>
                  <input
                    type="text"
                    value={newLoanDuration}
                    onChange={(e) => setNewLoanDuration(e.target.value)}
                    placeholder="Ex: 2 semaines, 1 mois..."
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Remarques ou état</label>
                <input
                  type="text"
                  value={newLoanNotes}
                  onChange={(e) => setNewLoanNotes(e.target.value)}
                  placeholder="Ex: Cartes sous protèges-cartes (sleeves), pions bien triés."
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-sky-400"
                />
              </div>
              <div className="flex gap-2 justify-end pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingLoan(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded"
                >
                  Publier l'annonce de prêt
                </button>
              </div>
            </form>
          )}

          {/* Loans Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {loans.map((l) => {
              const duration = l.loanDuration || l.maxDuration || '2 semaines';
              const conditionNotes = l.notes || l.condition || 'Boîte complète en bon état.';

              return (
                <div key={l.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span
                      className={`font-mono text-[11px] px-2 py-0.5 rounded ${
                        l.isAvailable
                          ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800'
                          : 'bg-slate-950 text-slate-500 border border-slate-800'
                      }`}
                    >
                      {l.isAvailable ? 'Disponible' : 'En cours de prêt'}
                    </span>
                    <span className="text-slate-400 font-mono">{duration}</span>
                  </div>

                  <div>
                    <h4 className="font-serif font-bold text-slate-100 text-base">{l.gameTitle}</h4>
                    <p className="text-xs text-slate-400 mt-1">{conditionNotes}</p>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      Propriétaire : <strong className="text-slate-200">{l.ownerName}</strong>
                    </span>

                    {l.isAvailable ? (
                      <button
                        type="button"
                        onClick={() => onRequestLoan(l.id, currentMember.name)}
                        className="text-orange-400 hover:text-orange-300 font-medium cursor-pointer"
                      >
                        Demander l'emprunt
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-500 italic">Emprunté par {l.requestedBy}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: CARPOOLING */}
      {activeTab === 'carpool' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="font-serif text-lg font-bold text-slate-100">
                Covoiturage entre Joueurs
              </h3>
              <p className="text-xs text-slate-400">
                Partagez un trajet pour les soirées du vendredi ou les déplacements vers les festivals de jeux.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsAddingCarpool(!isAddingCarpool)}
              className="px-3.5 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Proposer un trajet</span>
            </button>
          </div>

          {/* New Carpool Form */}
          {isAddingCarpool && (
            <form onSubmit={handleCreateCarpoolSubmit} className="p-4 rounded-xl bg-slate-900 border border-sky-900 space-y-3 text-xs">
              <h4 className="font-bold text-slate-100">Proposer des places dans votre véhicule :</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Point de départ (Ville / Quartier) *</label>
                  <input
                    type="text"
                    required
                    value={newCarpoolOrigin}
                    onChange={(e) => setNewCarpoolOrigin(e.target.value)}
                    placeholder="Ex: Centre-ville, Gare SNCF..."
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Destination</label>
                  <input
                    type="text"
                    value={newCarpoolDestination}
                    onChange={(e) => setNewCarpoolDestination(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Date & Heure</label>
                  <input
                    type="text"
                    value={newCarpoolDate}
                    onChange={(e) => setNewCarpoolDate(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>
              <div className="flex gap-2 justify-end pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingCarpool(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded"
                >
                  Publier le covoiturage
                </button>
              </div>
            </form>
          )}

          {/* Carpool Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {carpools.map((cp) => {
              const maxSeats = cp.availableSeats ?? cp.seatsAvailable ?? 3;
              const remainingSeats = maxSeats - cp.passengers.length;
              const hasJoined = cp.passengers.includes(currentMember.name);
              const depCity = cp.origin || cp.departureCity || 'Local';
              const destCity = cp.destination || cp.eventTitle || 'Maison des Associations';
              const depTime = cp.dateTime || cp.departureTime || 'Vendredi à 19h30';

              return (
                <div key={cp.id} className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-sky-400">Conducteur : {cp.driverName}</span>
                    <span className="text-slate-400 font-mono">{depTime}</span>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-200">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                      <span><strong>Départ :</strong> {depCity}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
                      <span><strong>Arrivée :</strong> {destCity}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      Places restantes : <strong className="text-orange-400">{remainingSeats}</strong> / {maxSeats}
                    </span>

                    {hasJoined ? (
                      <span className="text-xs font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-800 px-2 py-0.5 rounded">
                        ✓ Passager confirmé
                      </span>
                    ) : remainingSeats > 0 ? (
                      <button
                        type="button"
                        onClick={() => onJoinCarpool(cp.id, currentMember.name)}
                        className="px-3 py-1 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded text-xs cursor-pointer"
                      >
                        Réserver 1 place
                      </button>
                    ) : (
                      <span className="text-xs text-slate-500 italic">Voiture complète</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
