import React from 'react';
import { 
  Users, 
  Dice6, 
  MapPin, 
  Clock, 
  ExternalLink, 
  Sparkles,
  Sword,
  Scroll,
  ArrowRight
} from 'lucide-react';
import { Member } from '../types';
import { SalamandreLogo } from './SalamandreLogo';

interface AboutPageProps {
  onNavigateToActivities: () => void;
  onNavigateToGames: () => void;
  onOpenJoinModal: () => void;
  members: Member[];
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onNavigateToActivities,
  onNavigateToGames,
  onOpenJoinModal,
  members,
}) => {
  return (
    <div className="space-y-16 py-6 pb-20">
      {/* Hero Section with Official Logo & Mascot */}
      <section className="relative overflow-hidden rounded-2xl border border-sky-950/80 bg-gradient-to-br from-[#071328] via-[#09152e] to-[#040812] shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-10 lg:p-12">
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-2 text-xs font-mono text-sky-400 uppercase tracking-widest">
              <span>Association Loi 1901</span>
              <span>·</span>
              <span className="text-orange-400">Jeux & Imaginaire</span>
              <span>·</span>
              <span className="text-yellow-400">Depuis 2023</span>
            </div>

            <div className="flex items-center gap-4">
              <div className="p-1 rounded-full bg-sky-950/60 border border-sky-500/30 shrink-0">
                <SalamandreLogo size={68} />
              </div>
              <h1 className="font-serif text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
                Autour d'une table, <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-amber-300 to-sky-400">
                  la salamandre veille sur vos dés.
                </span>
              </h1>
            </div>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              <strong>Les Dés De La Salamandre</strong> réunit passionnés, stratèges et curieux 
              pour partager le plaisir des jeux de société modernes, du jeu de rôle sur table et des wargames. 
              Une atmosphère chaleureuse, inclusive et bienveillante où chaque lancer de dé raconte une aventure.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={onOpenJoinModal}
                className="px-6 py-3 text-sm font-bold text-slate-950 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 rounded-xl transition-all shadow-lg shadow-orange-950/50 cursor-pointer flex items-center gap-2"
              >
                <span>Rejoindre l'aventure (1ère séance offerte)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onNavigateToActivities}
                className="px-5 py-3 text-sm font-medium text-sky-200 hover:text-white bg-slate-900/90 border border-sky-800/60 hover:border-sky-400 rounded-xl transition-colors cursor-pointer"
              >
                Consulter les prochaines soirées
              </button>
            </div>

            {/* Quick trust metrics */}
            <div className="pt-6 border-t border-sky-950/80 grid grid-cols-3 gap-4 text-slate-400">
              <div>
                <span className="block text-2xl font-bold font-mono text-orange-400 tabular-nums">350+</span>
                <span className="text-xs">Jeux en libre accès</span>
              </div>
              <div>
                <span className="block text-2xl font-bold font-mono text-sky-400 tabular-nums">2x</span>
                <span className="text-xs">Rencontres par semaine</span>
              </div>
              <div>
                <span className="block text-2xl font-bold font-mono text-yellow-400 tabular-nums">15 €</span>
                <span className="text-xs">Adhésion annuelle</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="relative rounded-xl overflow-hidden border border-sky-900/60 shadow-2xl bg-slate-950 group">
              <img
                src="/src/assets/images/hero_salamandre_tabletop_1790175065782.jpg"
                alt="Ambiance conviviale autour d'une table de jeu à l'association Les Dés De La Salamandre"
                className="w-full h-[320px] sm:h-[400px] object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/30 to-transparent flex items-end p-5">
                <div className="text-xs text-slate-300 space-y-1">
                  <p className="font-semibold text-orange-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                    Soirée jeux chaque vendredi soir dès 20h
                  </p>
                  <p className="text-slate-400">Règles expliquées en début de partie par nos animateurs bénévoles.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Link to Official Facebook Page */}
      <section className="bg-sky-950/30 border border-sky-900/40 rounded-xl p-5 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-sky-600/20 border border-sky-500/40 flex items-center justify-center text-sky-400 shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">Rejoignez aussi notre communauté sur Facebook !</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Photos de soirées, actualités en direct et annonces de dernière minute sur notre page officielle.
            </p>
          </div>
        </div>
        <a
          href="https://www.facebook.com/people/Les-D%C3%A9s-De-La-Salamandre/61577810063926/"
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-sky-800/60 hover:border-sky-400 text-sky-200 text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
        >
          <span>Voir la page Facebook</span>
          <ExternalLink className="w-3.5 h-3.5 text-orange-400" />
        </a>
      </section>

      {/* 4 Piliers Ludiques */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-slate-100">
            Les 4 Univers Pratiqués
          </h2>
          <p className="text-sm text-slate-400">
            Que vous ayez 20 minutes pour un jeu de cartes ou 5 heures pour une campagne épique, une table vous attend.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-orange-500/50 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
                <Dice6 className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-100">Jeux de Plateau Modernes</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                De la stratégie experte (Terraforming Mars, Dune) aux jeux d’ambiance rythmés (Codenames, Trio, Just One) et coopératifs immersifs.
              </p>
            </div>
            <button
              type="button"
              onClick={onNavigateToGames}
              className="mt-4 pt-3 border-t border-slate-800 text-xs text-orange-400 hover:text-orange-300 font-medium flex items-center justify-between cursor-pointer"
            >
              <span>Explorer la ludothèque</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-sky-500/50 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                <Scroll className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-100">Jeux de Rôle (JDR)</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Campagnes suivies et one-shots découverte : Donjons & Dragons, L'Appel de Cthulhu, Vaesen, Warhammer Fantasy et créations narratives.
              </p>
            </div>
            <button
              type="button"
              onClick={onNavigateToActivities}
              className="mt-4 pt-3 border-t border-slate-800 text-xs text-sky-400 hover:text-sky-300 font-medium flex items-center justify-between cursor-pointer"
            >
              <span>Tables du week-end</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-yellow-500/50 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center text-yellow-400">
                <Sword className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-100">Figurines & Wargames</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Tables avec décors modulaires, escarmouches tactiques, Warhammer 40k, Kill Team et séances d'initiation à la peinture sur figurines.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-500">
              Atelier modélisme mensuel
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-orange-500/50 transition-all flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-100">Tournois & Événements</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Bourses aux jeux d'occasion, nuits blanches du jeu, tournois amicaux sans prise de tête et sorties groupées vers les grands festivals (Cannes, PEL).
              </p>
            </div>
            <button
              type="button"
              onClick={onNavigateToActivities}
              className="mt-4 pt-3 border-t border-slate-800 text-xs text-orange-400 hover:text-orange-300 font-medium flex items-center justify-between cursor-pointer"
            >
              <span>Voir le calendrier</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Visuels immersifs de l'association */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-900/70 flex flex-col">
          <img
            src="/src/assets/images/boardgames_collection_shelf_1790175078821.jpg"
            alt="Étagères de jeux de société de l'association Les Dés De La Salamandre"
            className="w-full h-56 object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="p-5 flex-1 flex flex-col justify-between">
            <div>
              <span className="text-xs font-mono text-sky-400">La Ludothèque</span>
              <h4 className="font-serif text-lg font-bold text-slate-100 mt-1">Un trésor de plus de 350 jeux</h4>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Des grands classiques indémodables aux dernières pépites récompensées à Essen et Cannes. Les boîtes sont inspectées et protégées par notre équipe de bénévoles. Emprunt possible pour les adhérents.
              </p>
            </div>
            <button
              type="button"
              onClick={onNavigateToGames}
              className="mt-4 text-xs font-semibold text-orange-400 hover:text-orange-300 flex items-center gap-1.5 cursor-pointer"
            >
              <span>Consulter le catalogue en ligne</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-900/70 flex flex-col">
          <img
            src="/src/assets/images/tabletop_rpg_session_1790175090917.jpg"
            alt="Session de jeu de rôle sur table avec dés polyédriques et parchemins"
            className="w-full h-56 object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="p-5 flex-1 flex flex-col justify-between">
            <div>
              <span className="text-xs font-mono text-orange-400">Le Pôle Rôle & Imaginaire</span>
              <h4 className="font-serif text-lg font-bold text-slate-100 mt-1">Pour rôlistes aguerris ou novices</h4>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Nos Maîtres du Jeu accueillent avec grand plaisir les personnes n'ayant jamais osé franchir le pas du jeu de rôle. Fiches de personnages prétirées et dés fournis sur place !
              </p>
            </div>
            <button
              type="button"
              onClick={onNavigateToActivities}
              className="mt-4 text-xs font-semibold text-sky-400 hover:text-sky-300 flex items-center gap-1.5 cursor-pointer"
            >
              <span>Réserver une place à une table JDR</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Informations Pratiques & Adhésion (15€) */}
      <section className="rounded-2xl border border-sky-950/80 bg-slate-900/40 p-6 sm:p-10 space-y-8">
        <div className="max-w-2xl">
          <span className="text-xs font-mono text-sky-400 uppercase tracking-wider">Fonctionnement & Tarifs</span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-slate-100 mt-1">
            Comment participer aux activités ?
          </h2>
          <p className="text-sm text-slate-400 mt-2">
            L'association est ouverte à toute personne à partir de 14 ans (ou accompagnée d'un adulte). Aucune connaissance préalable requise !
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold font-mono">
              1
            </div>
            <h3 className="font-bold text-slate-200 text-sm">Première Soirée Gratuite</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Venez tester l'ambiance un vendredi soir sans débourser un centime. Nos animateurs vous intégreront directement à une table adaptée.
            </p>
            <div className="text-xs text-emerald-400 font-medium">0 € sans engagement</div>
          </div>

          <div className="p-5 rounded-xl bg-slate-950 border border-orange-500/50 relative space-y-3 shadow-lg shadow-orange-950/20">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 text-slate-950 flex items-center justify-center font-bold font-mono">
              2
            </div>
            <h3 className="font-bold text-white text-sm">Adhésion Annuelle Standard</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Accès illimité à toutes les soirées de l'année, emprunt de jeux à la ludothèque, accès à l'espace membres sécurisé et salons de discussion privés.
            </p>
            <div className="text-base font-bold text-orange-400 font-mono">15 € / an</div>
          </div>

          <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold font-mono">
              3
            </div>
            <h3 className="font-bold text-slate-200 text-sm">Tarif Réduit & Étudiants</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Applicable aux étudiants, demandeurs d'emploi et mineurs. Formule accessible pour jouer toute l'année à petit prix.
            </p>
            <div className="text-base font-bold text-sky-400 font-mono">10 € / an</div>
          </div>
        </div>

        {/* Practical cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-semibold text-slate-200">Lieu des rencontres</p>
              <p className="text-slate-400">Maison des Associations & Salle Municipale Feu Follet.</p>
              <p className="text-slate-500">Parking gratuit sur place, arrêt de transport en commun à 3 minutes à pied.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-semibold text-slate-200">Créneaux d'ouverture</p>
              <p className="text-slate-400">Chaque vendredi de 20h00 à 00h30 (et souvent plus tard !).</p>
              <p className="text-slate-500">Séances JDR & tournois un samedi ou dimanche sur deux selon planning.</p>
            </div>
          </div>
        </div>
      </section>

      {/* L'Équipe du Bureau & Bénévoles */}
      <section className="space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h2 className="font-serif text-2xl font-bold text-slate-100">Le Bureau & Les Bénévoles</h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Une équipe de passionnés engagés pour faire vivre le jeu sous toutes ses formes.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {members.map((m) => (
            <div key={m.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 hover:border-sky-900 transition-colors">
              <div className="flex items-center gap-3">
                <img
                  src={m.avatar}
                  alt={m.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-orange-500/50"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-semibold text-slate-100 text-sm">{m.name}</h4>
                  <span className="text-[11px] text-sky-400 font-mono block">{m.roleTitle}</span>
                </div>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed line-clamp-3">
                {m.bio}
              </p>
              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-500 flex items-center gap-1">
                <span>Jeux fétiches :</span>
                <span className="text-slate-300 font-medium truncate">{m.favoriteGames.slice(0, 2).join(', ')}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
