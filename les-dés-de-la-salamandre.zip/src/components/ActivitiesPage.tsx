import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  CheckCircle2, 
  Lock, 
  Search, 
  Sparkles,
  UserCheck
} from 'lucide-react';
import { EventItem, Member } from '../types';

interface ActivitiesPageProps {
  events: EventItem[];
  currentMember: Member | null;
  onBookSeat: (eventId: string, userName: string) => void;
  onCancelBooking: (eventId: string, userName: string) => void;
  onOpenJoinModal: () => void;
}

export const ActivitiesPage: React.FC<ActivitiesPageProps> = ({
  events,
  currentMember,
  onBookSeat,
  onCancelBooking,
  onOpenJoinModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [onlyAvailable, setOnlyAvailable] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [guestName, setGuestName] = useState<string>('');
  const [bookingEventId, setBookingEventId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'Toutes les activités' },
    { id: 'plateau', label: 'Jeux de Société' },
    { id: 'jdr', label: 'Jeux de Rôle' },
    { id: 'tournoi', label: 'Tournois' },
    { id: 'initiation', label: 'Initiations' },
    { id: 'membre-exclusif', label: 'Spécial Membres' },
  ];

  const filteredEvents = events.filter((evt) => {
    if (selectedCategory !== 'all' && evt.category !== selectedCategory) {
      return false;
    }
    if (onlyAvailable && evt.reservedSeats >= evt.maxSeats) {
      return false;
    }
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchTitle = evt.title.toLowerCase().includes(q);
      const matchDesc = evt.description.toLowerCase().includes(q);
      const matchHost = evt.host.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchHost) return false;
    }
    return true;
  });

  const handleBookingSubmit = (eventId: string) => {
    const attendeeName = currentMember ? currentMember.name : guestName.trim();
    if (!attendeeName) return;
    onBookSeat(eventId, attendeeName);
    setBookingEventId(null);
    setGuestName('');
  };

  return (
    <div className="space-y-8 py-6 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <span className="text-xs font-mono text-sky-400 uppercase tracking-widest">
            Calendrier & Inscriptions
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl font-extrabold text-slate-100 mt-1">
            Les Activités à Venir
          </h1>
          <p className="text-sm text-slate-400 mt-2 max-w-2xl">
            Réservez gratuitement votre place autour de la table. Pour les sessions exclusives, 
            l'adhésion annuelle (15 €) donne un accès illimité.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-1 bg-slate-900 border border-slate-800 rounded-lg flex items-center text-xs">
            <span className="px-3 py-1 text-slate-400">Total sessions :</span>
            <span className="font-mono font-bold text-orange-400 px-2 py-0.5 bg-slate-950 rounded border border-slate-800 tabular-nums">
              {events.length}
            </span>
          </div>
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-sky-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher une soirée, un jeu, un MJ..."
              className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 focus:border-sky-400 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none transition-colors"
            />
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer self-start sm:self-center">
            <input
              type="checkbox"
              checked={onlyAvailable}
              onChange={(e) => setOnlyAvailable(e.target.checked)}
              className="w-4 h-4 rounded border-slate-700 text-orange-500 focus:ring-orange-500 bg-slate-900"
            />
            <span>Places disponibles uniquement</span>
          </label>
        </div>

        {/* Category Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-sky-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Events List */}
      {filteredEvents.length === 0 ? (
        <div className="text-center py-16 border border-slate-800 rounded-2xl bg-slate-900/30 space-y-3">
          <Calendar className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="font-serif text-lg text-slate-200">Aucune activité trouvée</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Aucun événement ne correspond à vos filtres actuels.
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('all');
              setOnlyAvailable(false);
              setSearchQuery('');
            }}
            className="text-xs text-sky-400 hover:underline pt-2 cursor-pointer"
          >
            Réinitialiser les filtres
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredEvents.map((evt) => {
            const isFull = evt.reservedSeats >= evt.maxSeats;
            const remaining = Math.max(0, evt.maxSeats - evt.reservedSeats);
            const isAlreadyBooked = currentMember
              ? evt.attendees.includes(currentMember.name)
              : false;

            const percentage = Math.round((evt.reservedSeats / evt.maxSeats) * 100);

            return (
              <div
                key={evt.id}
                className={`flex flex-col justify-between rounded-xl border bg-slate-900/70 p-6 transition-all ${
                  evt.isMemberOnly
                    ? 'border-sky-900/60 hover:border-sky-500/70'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="space-y-4">
                  {/* Top line metadata */}
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 text-slate-400">
                      <span className="font-semibold text-orange-400">{evt.categoryLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span>{evt.complexity}</span>
                    </div>

                    {evt.isMemberOnly && (
                      <span className="flex items-center gap-1 text-[11px] font-mono text-sky-400 bg-sky-950/70 border border-sky-800/60 px-2 py-0.5 rounded">
                        <Lock className="w-3 h-3 text-orange-400" /> Adhérents
                      </span>
                    )}
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="font-serif text-xl font-bold text-slate-100 group-hover:text-sky-300">
                      {evt.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
                      {evt.description}
                    </p>
                  </div>

                  {/* Practical details grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 text-xs text-slate-300">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-sky-400 shrink-0" />
                      <span>{evt.formattedDate}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-orange-400 shrink-0" />
                      <span>{evt.time}</span>
                    </div>
                    <div className="flex items-center gap-2 sm:col-span-2">
                      <MapPin className="w-4 h-4 text-yellow-400 shrink-0" />
                      <span className="truncate">{evt.location}</span>
                    </div>
                  </div>

                  {/* Host note */}
                  <div className="text-xs text-slate-400 pt-2 border-t border-slate-800 flex items-center justify-between">
                    <span>
                      Organisé par : <strong className="text-slate-200">{evt.host}</strong> ({evt.hostRole})
                    </span>
                    {evt.bringItems && (
                      <span className="text-[11px] text-slate-500 italic hidden sm:inline">
                        À apporter : {evt.bringItems.slice(0, 30)}...
                      </span>
                    )}
                  </div>

                  {/* Seat capacity gauge */}
                  <div className="space-y-1.5 pt-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">Jauge des inscriptions :</span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        <strong className="text-orange-400">{evt.reservedSeats}</strong> / {evt.maxSeats} places ({remaining} restantes)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isFull
                            ? 'bg-red-500'
                            : percentage > 75
                            ? 'bg-orange-500'
                            : 'bg-sky-400'
                        }`}
                        style={{ width: `${Math.min(100, percentage)}%` }}
                      />
                    </div>
                  </div>

                  {/* Attendees peek */}
                  {evt.attendees.length > 0 && (
                    <div className="text-[11px] text-slate-500 flex items-center gap-1.5 flex-wrap">
                      <Users className="w-3.5 h-3.5 text-sky-400" />
                      <span>Inscrits récents :</span>
                      <span className="text-slate-300">{evt.attendees.slice(0, 3).join(', ')}</span>
                      {evt.attendees.length > 3 && (
                        <span>+{evt.attendees.length - 3} autres</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Bottom Action Area */}
                <div className="mt-6 pt-4 border-t border-slate-800">
                  {isAlreadyBooked ? (
                    <div className="flex items-center justify-between gap-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg p-3">
                      <div className="flex items-center gap-2 text-xs text-emerald-300 font-medium">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Vous êtes inscrit(e) à cette séance</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => onCancelBooking(evt.id, currentMember!.name)}
                        className="text-xs text-slate-400 hover:text-red-400 hover:underline cursor-pointer"
                      >
                        Annuler ma place
                      </button>
                    </div>
                  ) : evt.isMemberOnly && !currentMember ? (
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-sky-950/40 border border-sky-800/60 rounded-lg p-3">
                      <div className="flex items-center gap-2 text-xs text-sky-300">
                        <Lock className="w-4 h-4 text-orange-400 shrink-0" />
                        <span>Réservé aux adhérents de l'association (15 €/an)</span>
                      </div>
                      <button
                        type="button"
                        onClick={onOpenJoinModal}
                        className="px-3 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 rounded-md whitespace-nowrap cursor-pointer"
                      >
                        Adhérer pour participer
                      </button>
                    </div>
                  ) : isFull ? (
                    <div className="text-center py-2 px-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-500 font-mono">
                      Complet — Inscription sur liste d'attente au local
                    </div>
                  ) : bookingEventId === evt.id ? (
                    <div className="space-y-2 bg-slate-950 p-3 rounded-lg border border-slate-700">
                      <label className="block text-xs text-slate-300">
                        Indiquez votre prénom ou pseudo pour réserver :
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={guestName}
                          onChange={(e) => setGuestName(e.target.value)}
                          placeholder="Ex: Thomas, Marie..."
                          className="flex-1 px-3 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-sky-400"
                        />
                        <button
                          type="button"
                          onClick={() => handleBookingSubmit(evt.id)}
                          disabled={!guestName.trim()}
                          className="px-3 py-1.5 text-xs font-bold text-slate-950 bg-orange-500 hover:bg-orange-400 disabled:opacity-50 rounded cursor-pointer"
                        >
                          Confirmer
                        </button>
                        <button
                          type="button"
                          onClick={() => setBookingEventId(null)}
                          className="px-2 py-1.5 text-xs text-slate-400 hover:text-white cursor-pointer"
                        >
                          Annuler
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        if (currentMember) {
                          handleBookingSubmit(evt.id);
                        } else {
                          setBookingEventId(evt.id);
                        }
                      }}
                      className="w-full py-2.5 px-4 text-xs font-bold text-slate-950 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 active:scale-[0.99] rounded-lg transition-all shadow-sm cursor-pointer flex items-center justify-center gap-2"
                    >
                      <UserCheck className="w-4 h-4" />
                      <span>Réserver ma place (Gratuit)</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
