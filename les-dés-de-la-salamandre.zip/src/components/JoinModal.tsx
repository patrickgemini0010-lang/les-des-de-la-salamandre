import React, { useState } from 'react';
import { X, Check, Shield } from 'lucide-react';
import { SalamandreLogo } from './SalamandreLogo';

interface JoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (name: string, plan: string) => void;
}

export const JoinModal: React.FC<JoinModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [selectedPlan, setSelectedPlan] = useState<'decouverte' | 'standard' | 'reduit'>('standard');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [interests, setInterests] = useState<string[]>(['Jeux de société modernes']);
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const toggleInterest = (interest: string) => {
    if (interests.includes(interest)) {
      setInterests(interests.filter((i) => i !== interest));
    } else {
      setInterests([...interests, interest]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim()) return;

    setIsSubmitted(true);
    setTimeout(() => {
      onSuccess(fullName, selectedPlan);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-sky-900/60 rounded-2xl p-6 sm:p-8 shadow-2xl my-8 text-slate-200">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          <div className="py-12 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-slate-100">
              Bienvenue chez Les Dés De La Salamandre !
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
              Votre demande a bien été enregistrée pour <strong>{fullName}</strong>. Vous recevrez un récapitulatif 
              par courriel avec toutes les informations pour participer dès ce vendredi à 20h !
            </p>
            <div className="pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-lg text-xs cursor-pointer"
              >
                Accéder au site
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="shrink-0">
                <SalamandreLogo size={48} />
              </div>
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-sky-400 uppercase tracking-wider">
                  <span>Adhésion 2026 & Séance d'essai</span>
                </div>
                <h2 className="font-serif text-2xl font-bold text-slate-100 mt-0.5">
                  Rejoindre l'Association
                </h2>
              </div>
            </div>

            {/* Plan selection */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setSelectedPlan('decouverte')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedPlan === 'decouverte'
                    ? 'bg-sky-950/50 border-sky-400 text-slate-100'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-sky-400">Séance Découverte</div>
                <div className="font-mono text-lg font-bold text-emerald-400 mt-0.5">0 €</div>
                <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                  1 soirée vendredi offerte sans engagement.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPlan('standard')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedPlan === 'standard'
                    ? 'bg-orange-950/40 border-orange-500 text-slate-100'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-orange-400">Adhésion Annuelle</div>
                <div className="font-mono text-lg font-bold text-white mt-0.5">15 € / an</div>
                <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                  Accès illimité + prêts de jeux + salons privés.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPlan('reduit')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedPlan === 'reduit'
                    ? 'bg-sky-950/50 border-sky-400 text-slate-100'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-yellow-400">Tarif Réduit</div>
                <div className="font-mono text-lg font-bold text-white mt-0.5">10 € / an</div>
                <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                  Étudiants, demandeurs d'emploi, mineurs.
                </p>
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Nom & Prénom *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ex: Alexandre Martin"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-sky-400 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Adresse Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="alexandre@exemple.fr"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-sky-400 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Téléphone (facultatif, pour covoiturage / rappels)
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="06 XX XX XX XX"
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-sky-400 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none"
                />
              </div>

              {/* Interests checkboxes */}
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">
                  Vos univers favoris :
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Jeux de société modernes',
                    'Jeux de rôle (JDR)',
                    'Figurines & Wargames',
                    'Tournois amicaux',
                    'Jeux d’ambiance rapides',
                  ].map((item) => {
                    const isChecked = interests.includes(item);
                    return (
                      <button
                        key={item}
                        type="button"
                        onClick={() => toggleInterest(item)}
                        className={`px-3 py-1.5 rounded-lg border text-[11px] transition-colors cursor-pointer ${
                          isChecked
                            ? 'bg-sky-500/20 border-sky-400 text-sky-200 font-medium'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        {isChecked ? '✓ ' : '+ '}
                        {item}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Un mot pour le bureau ou une question ?
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Précisez par exemple si vous venez avec des amis ou si vous souhaitez un accompagnement sur un jeu..."
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-sky-400 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-lg text-xs shadow-md transition-all cursor-pointer"
                >
                  Valider mon adhésion
                </button>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-500 pt-1">
                <Shield className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span>
                  Vos données restent strictement confidentielles et ne sont jamais cédées à des tiers.
                </span>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
