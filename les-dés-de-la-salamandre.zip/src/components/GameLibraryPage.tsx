import React, { useState } from 'react';
import { Search, Users, Clock, Star, Sparkles, BookOpen } from 'lucide-react';
import { GameItem } from '../types';

interface GameLibraryPageProps {
  games: GameItem[];
  onOpenJoinModal: () => void;
}

export const GameLibraryPage: React.FC<GameLibraryPageProps> = ({ games, onOpenJoinModal }) => {
  const [search, setSearch] = useState('');
  const [complexityFilter, setComplexityFilter] = useState<string>('all');
  const [playersFilter, setPlayersFilter] = useState<string>('all');
  const [votedGameId, setVotedGameId] = useState<string | null>(null);

  // Month game vote state
  const [voteCounts, setVoteCounts] = useState<{ [id: string]: number }>({
    'g-1': 18, // Dune Imperium
    'g-2': 14, // Ark Nova
    'g-3': 22, // Harmonies
    'g-5': 9,  // Root
  });

  const handleVote = (gameId: string) => {
    if (votedGameId) return;
    setVotedGameId(gameId);
    setVoteCounts((prev) => ({
      ...prev,
      [gameId]: (prev[gameId] || 0) + 1,
    }));
  };

  const filteredGames = games.filter((game) => {
    if (search.trim()) {
      const q = search.toLowerCase();
      const match =
        game.title.toLowerCase().includes(q) ||
        game.category.toLowerCase().includes(q) ||
        game.tags.some((t) => t.toLowerCase().includes(q));
      if (!match) return false;
    }

    if (complexityFilter !== 'all' && game.complexity !== complexityFilter) {
      return false;
    }

    if (playersFilter === 'duo' && (game.playersMin > 2 || game.playersMax < 2)) {
      return false;
    }
    if (playersFilter === 'medium' && !(game.playersMin <= 4 && game.playersMax >= 3)) {
      return false;
    }
    if (playersFilter === 'large' && game.playersMax < 5) {
      return false;
    }

    return true;
  });

  return (
    <div className="space-y-12 py-6 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <span className="text-xs font-mono text-sky-400 uppercase tracking-widest">
            Fonds de Jeux Associatif
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl font-extrabold text-slate-100 mt-1">
            La Ludothèque de la Salamandre
          </h1>
          <p className="text-sm text-slate-400 mt-2 max-w-2xl">
            Plus de 350 jeux disponibles au local chaque semaine. Les adhérents peuvent également emprunter 
            les boîtes pour jouer chez eux en famille ou entre amis !
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-1 bg-slate-900 border border-slate-800 rounded-lg flex items-center text-xs">
            <span className="px-3 py-1 text-slate-400">Catalogue en ligne :</span>
            <span className="font-mono font-bold text-orange-400 px-2 py-0.5 bg-slate-950 rounded border border-slate-800 tabular-nums">
              {games.length} jeux indexés
            </span>
          </div>
        </div>
      </div>

      {/* Featured Vote Box (Vote pour la grande soirée) */}
      <section className="rounded-2xl border border-sky-900/60 bg-gradient-to-br from-[#06142a] via-slate-900 to-slate-900 p-6 sm:p-8 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-100">
                Vote Communautaire : Le Jeu Vedette de la Prochaine Soirée
              </h2>
              <p className="text-xs text-slate-400">
                Chaque mois, les joueurs élisent le grand jeu qui bénéficiera d'une table dédiée avec animateur expert.
              </p>
            </div>
          </div>
          {votedGameId && (
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1 rounded-full self-start">
              ✓ Votre vote a été comptabilisé
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {games.slice(0, 4).map((g) => {
            const votes = voteCounts[g.id] || 0;
            const isVoted = votedGameId === g.id;

            return (
              <div
                key={g.id}
                className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                  isVoted
                    ? 'bg-sky-950/50 border-sky-400'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>{g.complexity}</span>
                    <span className="font-mono text-orange-400 font-bold tabular-nums">
                      {votes} votes
                    </span>
                  </div>
                  <h4 className="font-serif font-bold text-slate-100 text-sm mt-1">{g.title}</h4>
                  <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">{g.category}</p>
                </div>

                <button
                  type="button"
                  onClick={() => handleVote(g.id)}
                  disabled={votedGameId !== null}
                  className={`mt-3 w-full py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    isVoted
                      ? 'bg-sky-500 text-slate-950 font-bold'
                      : votedGameId !== null
                      ? 'bg-slate-900 text-slate-600 cursor-not-allowed'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-sky-500'
                  }`}
                >
                  {isVoted ? 'Voté !' : 'Voter pour ce jeu'}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Filter and Search Bar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-sky-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher par titre, mécanique, catégorie (ex: Dune, Cartes, 4 joueurs)..."
              className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 focus:border-sky-400 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none transition-colors"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={complexityFilter}
              onChange={(e) => setComplexityFilter(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-sky-400"
            >
              <option value="all">Toutes complexités</option>
              <option value="Accessible">Accessible / Famille</option>
              <option value="Intermédiaire">Intermédiaire / Initié</option>
              <option value="Stratégique">Stratégique / Expert</option>
            </select>

            <select
              value={playersFilter}
              onChange={(e) => setPlayersFilter(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-sky-400"
            >
              <option value="all">Tout nombre de joueurs</option>
              <option value="duo">Duo (2 joueurs)</option>
              <option value="medium">3 à 4 joueurs</option>
              <option value="large">5 joueurs et plus</option>
            </select>
          </div>
        </div>
      </div>

      {/* Game Grid */}
      {filteredGames.length === 0 ? (
        <div className="text-center py-16 border border-slate-800 rounded-2xl bg-slate-900/30 space-y-3">
          <BookOpen className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="font-serif text-lg text-slate-200">Aucun jeu ne correspond à votre recherche</h3>
          <p className="text-xs text-slate-400">
            Essayez d'autres mots-clés ou réinitialisez les filtres.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearch('');
              setComplexityFilter('all');
              setPlayersFilter('all');
            }}
            className="text-xs text-sky-400 hover:underline pt-2 cursor-pointer"
          >
            Réinitialiser les filtres
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGames.map((game) => (
            <div
              key={game.id}
              className="p-5 rounded-xl bg-slate-900 border border-slate-800 hover:border-sky-900 transition-all flex flex-col justify-between shadow-md"
            >
              <div className="space-y-3">
                {/* Status + Rating */}
                <div className="flex items-center justify-between text-xs">
                  <span
                    className={`font-mono text-[11px] px-2 py-0.5 rounded ${
                      game.available
                        ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60'
                        : 'bg-slate-950 text-slate-400 border border-slate-800'
                    }`}
                  >
                    {game.available ? '● En rayon' : '○ Emprunté'}
                  </span>

                  <div className="flex items-center gap-1 text-yellow-400 font-mono">
                    <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                    <span>{game.rating}</span>
                  </div>
                </div>

                {/* Title & Category */}
                <div>
                  <h3 className="font-serif text-lg font-bold text-slate-100">{game.title}</h3>
                  <p className="text-xs text-sky-400 font-medium mt-0.5">{game.category}</p>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed line-clamp-3">
                  {game.description}
                </p>

                {/* Specs */}
                <div className="grid grid-cols-2 gap-2 pt-2 text-xs text-slate-300 border-t border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-sky-400" />
                    <span>
                      {game.playersMin === game.playersMax
                        ? `${game.playersMin} joueurs`
                        : `${game.playersMin} – ${game.playersMax} joueurs`}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-orange-400" />
                    <span>~{game.durationMin} min</span>
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 pt-1 text-[11px] text-slate-400">
                  {game.tags.map((tag) => (
                    <span key={tag} className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Loan hint */}
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span className="truncate max-w-[170px]">{game.location}</span>
                <button
                  type="button"
                  onClick={onOpenJoinModal}
                  className="text-orange-400 hover:text-orange-300 font-medium cursor-pointer"
                >
                  Emprunter →
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
