import React, { useState } from 'react';
import { Menu, X, Shield, Sparkles, User } from 'lucide-react';
import { Member } from '../types';
import { SalamandreLogo } from './SalamandreLogo';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentMember: Member | null;
  onOpenJoinModal: () => void;
  onToggleDiceModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  currentMember,
  onOpenJoinModal,
  onToggleDiceModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'association', label: "L'Association" },
    { id: 'activites', label: 'Activités & Agenda' },
    { id: 'ludotheque', label: 'La Ludothèque' },
    { id: 'membres', label: 'Espace Membres' },
  ];

  const handleNavClick = (tabId: string) => {
    setCurrentTab(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#070e1c]/90 backdrop-blur-md border-b border-sky-950/60 shadow-lg shadow-black/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Brand Wordmark with Real Logo */}
          <button
            type="button"
            onClick={() => handleNavClick('association')}
            className="flex items-center gap-3 text-left group cursor-pointer focus:outline-none"
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center transition-transform group-hover:scale-105 shrink-0">
              <SalamandreLogo size={42} />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-lg sm:text-xl font-bold tracking-tight text-white group-hover:text-sky-300 transition-colors">
                Les Dés De La Salamandre
              </span>
              <span className="text-[10px] text-sky-400 font-mono tracking-widest uppercase hidden sm:block">
                Jeux de Société & Rôle
              </span>
            </div>
          </button>

          {/* Zone 2: 4-6 Text Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
            {navLinks.map((link) => {
              const isActive = currentTab === link.id;
              return (
                <button
                  key={link.id}
                  type="button"
                  onClick={() => handleNavClick(link.id)}
                  className={`relative py-1 transition-colors hover:text-sky-300 cursor-pointer ${
                    isActive ? 'text-sky-400 font-semibold' : 'text-slate-300'
                  }`}
                >
                  {link.label}
                  {link.id === 'membres' && (
                    <span className="ml-1.5 inline-flex items-center text-[10px] text-orange-400 font-mono">
                      <Shield className="w-3 h-3 inline mr-0.5 text-sky-400" />
                      Privé
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-sky-400 to-orange-400 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1-2 Primary Actions */}
          <div className="hidden md:flex items-center gap-3">
            <button
              type="button"
              onClick={onToggleDiceModal}
              title="Lancer les dés"
              className="p-2 text-sky-300 hover:text-orange-400 hover:bg-slate-900 rounded-lg border border-sky-900/40 hover:border-sky-700 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-sky-400" />
            </button>

            {currentMember ? (
              <button
                type="button"
                onClick={() => handleNavClick('membres')}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-sky-900/60 text-xs text-sky-200 transition-colors cursor-pointer"
              >
                <div className="w-5 h-5 rounded-full overflow-hidden bg-slate-800 flex items-center justify-center border border-sky-500/50">
                  {currentMember.avatar ? (
                    <img src={currentMember.avatar} alt={currentMember.name} className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-3 h-3 text-slate-300" />
                  )}
                </div>
                <span className="font-medium truncate max-w-[120px]">{currentMember.name.split(' ')[0]}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleNavClick('membres')}
                className="px-3.5 py-1.5 text-xs font-semibold text-sky-200 hover:text-white bg-slate-900 hover:bg-slate-800 rounded-lg border border-sky-900/60 hover:border-sky-500 transition-colors cursor-pointer whitespace-nowrap"
              >
                Accès Membres
              </button>
            )}

            <button
              type="button"
              onClick={onOpenJoinModal}
              className="px-4 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 rounded-lg shadow-sm shadow-orange-950/40 transition-all cursor-pointer whitespace-nowrap"
            >
              Rejoindre l'Asso
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              type="button"
              onClick={onToggleDiceModal}
              className="p-2 text-sky-400 bg-slate-900 rounded-lg border border-sky-900/50"
            >
              <Sparkles className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-900 rounded-lg focus:outline-none"
              aria-label="Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-sky-950 bg-[#070e1c] px-4 pt-3 pb-5 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              type="button"
              onClick={() => handleNavClick(link.id)}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                currentTab === link.id
                  ? 'bg-sky-950/60 text-sky-300 border border-sky-800/60'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <span>{link.label}</span>
                {link.id === 'membres' && (
                  <span className="text-[10px] text-orange-400 font-mono flex items-center gap-1">
                    <Shield className="w-3 h-3 text-sky-400" /> Privé
                  </span>
                )}
              </div>
            </button>
          ))}
          <div className="pt-3 border-t border-sky-950 flex flex-col gap-2">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenJoinModal();
              }}
              className="w-full py-2.5 text-center text-sm font-bold text-slate-950 bg-gradient-to-r from-orange-500 to-amber-500 rounded-lg"
            >
              Rejoindre l'Asso (1ère séance offerte)
            </button>
            <button
              type="button"
              onClick={() => handleNavClick('membres')}
              className="w-full py-2 text-center text-xs font-medium text-slate-300 bg-slate-900 rounded-lg border border-sky-900/50"
            >
              {currentMember ? `Connecté: ${currentMember.name}` : 'Connexion Espace Membres'}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
