import React from 'react';
import { ExternalLink, MapPin, Clock } from 'lucide-react';
import { SalamandreLogo } from './SalamandreLogo';

interface FooterProps {
  onNavigate: (tabId: string) => void;
  onOpenJoinModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenJoinModal }) => {
  return (
    <footer className="border-t border-sky-950/80 bg-[#040812] text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Col with Real Logo */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-3">
              <SalamandreLogo size={40} />
              <span className="font-serif font-bold text-base text-slate-100">
                Les Dés De La Salamandre
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Association ludique loi 1901. Dédiée à la pratique du jeu de société moderne, 
              du jeu de rôle et du partage convivial.
            </p>
            <div className="pt-1">
              <a
                href="https://www.facebook.com/people/Les-D%C3%A9s-De-La-Salamandre/61577810063926/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 transition-colors font-medium"
              >
                <span>Page Officielle Facebook</span>
                <ExternalLink className="w-3.5 h-3.5 text-orange-400" />
              </a>
            </div>
          </div>

          {/* Nav links */}
          <div className="space-y-2">
            <h4 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] font-mono">
              Navigation
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('association')}
                  className="hover:text-sky-300 transition-colors cursor-pointer"
                >
                  L'Association & Le Bureau
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('activites')}
                  className="hover:text-sky-300 transition-colors cursor-pointer"
                >
                  Activités & Calendrier
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('ludotheque')}
                  className="hover:text-sky-300 transition-colors cursor-pointer"
                >
                  La Ludothèque (350+ jeux)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('membres')}
                  className="hover:text-sky-300 transition-colors cursor-pointer"
                >
                  Espace Membres Sécurisé
                </button>
              </li>
            </ul>
          </div>

          {/* Horaires et rendez-vous */}
          <div className="space-y-2">
            <h4 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] font-mono">
              Rendez-vous Ludiques
            </h4>
            <div className="space-y-2 text-slate-400">
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-300 block">Vendredi Soir :</strong>
                  <span>Dès 20h00 jusqu'à minuit passé</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-300 block">Lieu des rencontres :</strong>
                  <span>Maison des Associations, Salle Feu Follet</span>
                </div>
              </div>
            </div>
          </div>

          {/* Adhésion & Contact */}
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] font-mono">
              Nous Rejoindre
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Adhésion annuelle à 15 €. Première soirée découverte 100% offerte pour essayer sans engagement.
            </p>
            <button
              type="button"
              onClick={onOpenJoinModal}
              className="w-full py-2 px-3 text-center bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-bold rounded-lg transition-colors cursor-pointer"
            >
              Demander une adhésion (15 €)
            </button>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} Les Dés De La Salamandre — Association loi 1901.</p>
          <div className="flex items-center gap-4">
            <span className="text-sky-400">Bleu Azur</span>
            <span>·</span>
            <span className="text-orange-400">Orange Salamandre</span>
            <span>·</span>
            <span className="text-yellow-400">Dé Jaune</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
