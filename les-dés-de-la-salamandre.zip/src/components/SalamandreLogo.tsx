import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

export const SalamandreLogo: React.FC<LogoProps> = ({ className = '', size = 48 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Logo Les Dés De La Salamandre"
    >
      <defs>
        {/* Gradients matching the logo */}
        <linearGradient id="salamanderBody" x1="40" y1="40" x2="160" y2="160" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFA028" />
          <stop offset="50%" stopColor="#FF7A00" />
          <stop offset="100%" stopColor="#E65100" />
        </linearGradient>

        <linearGradient id="d20GradLight" x1="45" y1="80" x2="90" y2="135" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="100%" stopColor="#0284C7" />
        </linearGradient>

        <linearGradient id="d20GradDark" x1="45" y1="80" x2="90" y2="135" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#0284C7" />
          <stop offset="100%" stopColor="#0369A1" />
        </linearGradient>

        <linearGradient id="d6Yellow" x1="90" y1="95" x2="140" y2="145" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FDE047" />
          <stop offset="100%" stopColor="#EAB308" />
        </linearGradient>

        {/* Circular text path */}
        <path id="circleTextTop" d="M 32 100 A 68 68 0 0 1 168 100" />
        <path id="circleTextBottom" d="M 172 100 A 72 72 0 0 1 28 100" />
      </defs>

      {/* Outer Azure Blue Circular Arc */}
      <circle
        cx="100"
        cy="100"
        r="75"
        stroke="#00A0E9"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeDasharray="95 18 180 18"
        fill="none"
      />

      {/* Arched Text: LES DÉS DE LA */}
      <text fill="#00A0E9" fontSize="13.5" fontWeight="800" fontFamily="system-ui, sans-serif" letterSpacing="2">
        <textPath href="#circleTextTop" startOffset="50%" textAnchor="middle">
          LES DÉS DE LA
        </textPath>
      </text>

      {/* Arched Text: SALAMANDRE */}
      <text fill="#00A0E9" fontSize="14.5" fontWeight="900" fontFamily="system-ui, sans-serif" letterSpacing="2.5">
        <textPath href="#circleTextBottom" startOffset="50%" textAnchor="middle">
          SALAMANDRE
        </textPath>
      </text>

      {/* Central Group */}
      <g transform="translate(0, 2)">
        {/* Blue 20-sided Die (d20) */}
        <g id="d20">
          {/* Main icosahedron facets */}
          <polygon points="68,78 92,92 78,132 46,122 46,92" fill="url(#d20GradLight)" stroke="#0090D6" strokeWidth="1.8" />
          <polygon points="68,78 92,92 88,118 68,132" fill="url(#d20GradDark)" stroke="#0077B6" strokeWidth="1.8" />
          <polygon points="46,92 68,78 68,110" fill="#38BDF8" stroke="#0090D6" strokeWidth="1.5" />
          <polygon points="46,92 68,110 46,122" fill="#0284C7" stroke="#0077B6" strokeWidth="1.5" />
          <polygon points="68,110 92,92 88,118" fill="#00A0E9" stroke="#0284C7" strokeWidth="1.5" />
          <polygon points="68,110 88,118 68,132" fill="#0369A1" stroke="#0284C7" strokeWidth="1.5" />
          <polygon points="46,122 68,110 68,132" fill="#075985" stroke="#0284C7" strokeWidth="1.5" />
          {/* Subtle triangle facet highlight */}
          <polygon points="68,90 82,99 68,116 54,99" fill="#7DD3FC" opacity="0.6" stroke="#0284C7" strokeWidth="1" />
        </g>

        {/* Yellow 6-sided Die (d6) with Blue Pips */}
        <g id="d6">
          {/* Top isometric face */}
          <polygon points="115,96 138,103 118,110 95,103" fill="#FEF08A" stroke="#0090D6" strokeWidth="1.8" />
          {/* Left front face */}
          <polygon points="95,103 118,110 118,142 95,134" fill="url(#d6Yellow)" stroke="#0090D6" strokeWidth="1.8" />
          {/* Right face */}
          <polygon points="118,110 138,103 138,134 118,142" fill="#EAB308" stroke="#0090D6" strokeWidth="1.8" />

          {/* Blue Pips on front face (like 5 or 3) */}
          <circle cx="101" cy="113" r="2.2" fill="#00A0E9" />
          <circle cx="112" cy="116" r="2.2" fill="#00A0E9" />
          <circle cx="106" cy="122" r="2.2" fill="#00A0E9" />
          <circle cx="101" cy="129" r="2.2" fill="#00A0E9" />
          <circle cx="112" cy="132" r="2.2" fill="#00A0E9" />

          {/* Blue Pips on right face */}
          <circle cx="125" cy="116" r="2.2" fill="#00A0E9" />
          <circle cx="132" cy="122" r="2.2" fill="#00A0E9" />
          <circle cx="125" cy="129" r="2.2" fill="#00A0E9" />

          {/* Top Face pips */}
          <circle cx="116" cy="103" r="1.8" fill="#00A0E9" />
        </g>

        {/* The Orange Salamander curled over the dice */}
        <g id="salamander">
          {/* Curled Tail circling at bottom */}
          <path
            d="M 52 124 C 52 144, 76 156, 110 154 C 136 152, 154 138, 154 118 C 154 100, 142 82, 126 70"
            fill="none"
            stroke="url(#salamanderBody)"
            strokeWidth="14"
            strokeLinecap="round"
          />
          {/* Tail inner shading */}
          <path
            d="M 56 126 C 58 142, 80 152, 110 150 C 130 148, 148 136, 148 118"
            fill="none"
            stroke="#EA580C"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Back & Body */}
          <path
            d="M 68 76 C 60 62, 78 44, 102 42 C 128 40, 154 54, 156 80 C 158 98, 146 114, 134 122 C 122 110, 118 94, 96 90 C 82 88, 72 82, 68 76 Z"
            fill="url(#salamanderBody)"
            stroke="#D9480F"
            strokeWidth="1.5"
          />

          {/* Head */}
          <path
            d="M 68 74 C 62 76, 56 70, 60 56 C 64 46, 78 44, 94 48 C 104 52, 108 64, 102 74 C 94 82, 76 80, 68 74 Z"
            fill="url(#salamanderBody)"
          />

          {/* Cute Nostril & Smiling Mouth */}
          <circle cx="68" cy="69" r="1.2" fill="#9A3412" />
          <path d="M 66 74 C 74 78, 86 78, 98 64" fill="none" stroke="#9A3412" strokeWidth="1.8" strokeLinecap="round" />

          {/* Yellow Spots on the Salamander's back */}
          <circle cx="106" cy="52" r="3.2" fill="#FDE047" opacity="0.95" />
          <circle cx="116" cy="54" r="3.5" fill="#FDE047" opacity="0.95" />
          <circle cx="126" cy="58" r="4.0" fill="#FDE047" opacity="0.95" />
          <circle cx="136" cy="66" r="3.8" fill="#FDE047" opacity="0.95" />
          <circle cx="142" cy="76" r="3.5" fill="#FDE047" opacity="0.95" />

          <circle cx="102" cy="60" r="2.8" fill="#FDE047" opacity="0.95" />
          <circle cx="112" cy="62" r="3.2" fill="#FDE047" opacity="0.95" />
          <circle cx="122" cy="66" r="3.6" fill="#FDE047" opacity="0.95" />
          <circle cx="130" cy="74" r="3.2" fill="#FDE047" opacity="0.95" />
          <circle cx="136" cy="84" r="3.0" fill="#FDE047" opacity="0.95" />

          <circle cx="116" cy="72" r="2.6" fill="#FDE047" opacity="0.95" />
          <circle cx="124" cy="76" r="2.8" fill="#FDE047" opacity="0.95" />
          <circle cx="140" cy="94" r="3.0" fill="#FDE047" opacity="0.95" />
          <circle cx="142" cy="106" r="2.8" fill="#FDE047" opacity="0.95" />

          {/* Front Left Paws resting on the blue d20 */}
          <path
            d="M 88 88 C 88 94, 94 100, 102 102 C 104 102, 106 100, 104 96 C 102 92, 98 88, 92 86 Z"
            fill="#FF7A00"
            stroke="#D9480F"
            strokeWidth="1.2"
          />
          {/* Fingers */}
          <circle cx="92" cy="100" r="1.8" fill="#FFA028" />
          <circle cx="96" cy="102" r="1.8" fill="#FFA028" />
          <circle cx="101" cy="102" r="1.8" fill="#FFA028" />

          {/* Front Right Paws resting on the yellow d6 */}
          <path
            d="M 126 94 C 130 102, 134 108, 140 110 C 142 110, 144 106, 140 100 C 136 94, 132 90, 126 94 Z"
            fill="#FF7A00"
            stroke="#D9480F"
            strokeWidth="1.2"
          />
          <circle cx="132" cy="108" r="1.8" fill="#FFA028" />
          <circle cx="137" cy="111" r="1.8" fill="#FFA028" />
          <circle cx="142" cy="109" r="1.8" fill="#FFA028" />

          {/* Salamander Eye (Friendly Big Blue Eye with White Highlight) */}
          <ellipse cx="90" cy="58" rx="8" ry="9" fill="#00A0E9" stroke="#0369A1" strokeWidth="1.5" />
          <ellipse cx="90" cy="58" rx="5.5" ry="6.5" fill="#024A7A" />
          <circle cx="88" cy="55" r="2.5" fill="#FFFFFF" />
          <circle cx="92" cy="61" r="1.2" fill="#FFFFFF" />
          {/* Eyelid curve */}
          <path d="M 82 54 C 88 50, 96 52, 99 56" fill="none" stroke="#D9480F" strokeWidth="1.5" />
        </g>
      </g>
    </svg>
  );
};
