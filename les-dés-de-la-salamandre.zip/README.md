# Les Dés De La Salamandre — Site Web Officiel

Site web moderne, responsive et optimisé pour l'association ludique loi 1901 **Les Dés De La Salamandre**.

## Fonctionnalités incluses

- **Page Présentation** : Histoire, univers de jeu (Plateau, JDR, Figurines, Tournois), trombinoscope du bureau, tarifs (15 €/an) et lien Facebook officiel.
- **Agenda & Activités** : Calendrier des soirées du vendredi et sessions spéciales, réservation de places en temps réel avec jauge.
- **Ludothèque associative** : Catalogue de plus de 350 jeux, filtres (complexité, joueurs, durée) et vote mensuel communautaire.
- **Espace Membres Sécurisé** : Salons de discussion privés (chat en direct avec lancer de dés intégré), bourses aux prêts entre joueurs, événements adhérents et plateforme de covoiturage.
- **Boîte à outils ludique** : Lanceur de dés polyédriques virtuel (d4, d6, d8, d10, d12, d20 avec critiques, d100).
- **Charte graphique officielle** : Intégration du logo officiel, palette bleu azur, orange salamandre et jaune d6 sur fond feutré.

---

## 1. Démarrage en local

### Prérequis
- [Node.js](https://nodejs.org/) (version 18 ou supérieure)

### Installation
```bash
# 1. Installer les dépendances
npm install

# 2. Lancer le serveur de développement
npm run dev
```
L'application sera accessible sur `http://localhost:3000`.

---

## 2. Générer le site pour la production

Pour compiler l'application en fichiers HTML/CSS/JS statiques ultra-rapides et légers :

```bash
npm run build
```
Le résultat prêt à être déployé sera généré dans le dossier `dist/`.

---

## 3. Comment héberger et publier le site gratuitement ?

### Option A : Déploiement en 2 minutes sur Vercel (Recommandé)
1. Créez un compte gratuit sur [Vercel](https://vercel.com).
2. Cliquez sur **"Add New"** > **"Project"**.
3. Importez votre dépôt GitHub (ou glissez-déposez le dossier du projet via Vercel CLI).
4. Vercel détecte automatiquement Vite :
   - **Framework Preset** : Vite
   - **Build Command** : `npm run build`
   - **Output Directory** : `dist`
5. Cliquez sur **Deploy**. Votre site est en ligne avec certificat SSL (HTTPS) gratuit !

### Option B : Déploiement sur Netlify
1. Créez un compte gratuit sur [Netlify](https://www.netlify.com).
2. Rendez-vous dans **"Sites"** > **"Import from Git"** ou glissez directement le dossier `dist/` dans la zone de dépôt.
3. Le site est publié instantanément sur une URL du type `les-des-de-la-salamandre.netlify.app`.

### Option C : Lier un nom de domaine personnalisé (ex: `lesdesdelasalamandre.fr`)
- Achetez un nom de domaine chez un registrar français (ex: OVH, Gandi, Infomaniak ~7 €/an).
- Dans les paramètres Vercel ou Netlify, allez dans **Domains** > **Add domain**.
- Ajoutez les deux enregistrements DNS (CNAME et A) indiqués par la plateforme chez votre registrar.
- Votre domaine sera actif en HTTPS sécurisé en quelques minutes.
